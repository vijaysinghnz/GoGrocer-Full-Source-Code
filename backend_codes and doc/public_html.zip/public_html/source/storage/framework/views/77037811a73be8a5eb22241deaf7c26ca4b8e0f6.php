<?php $__env->startSection('content'); ?>
 <div class="container-fluid">
          <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title">Add Category</h4>
                  
                     <?php if(count($errors) > 0): ?>
                      <?php if($errors->any()): ?>
                        <div class="alert alert-primary" role="alert">
                          <?php echo e($errors->first()); ?>

                          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">×</span>
                          </button>
                        </div>
                      <?php endif; ?>
                  <?php endif; ?>
                  <form class="forms-sample" action="<?php echo e(route('AddNewCategory')); ?>" method="post" enctype="multipart/form-data">
                      <?php echo e(csrf_field()); ?>

                </div>
                <div class="card-body">

                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">Parent Category</label>
                          <select name="parent_id" class="form-control">
                              <option value="0">no parent</option>
                              <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorys): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        		          	<option value="<?php echo e($categorys->cat_id); ?>"><?php echo e($categorys->title); ?></option>
        		              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              
                          </select>
                        </div>
                      </div>

                    </div>

 
                     <div class="row">
                      <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">Category Title</label>
                          <input type="text" name="cat_name" class="form-control">
                        </div>
                      </div>

                    </div>
                    
                     <div class="row">
                      <div class="col-md-6">
                        <div class="form">
                          <label class="bmd-label-floating">Category Image</label>
                          <input type="file"name="cat_image" class="form-control">
                        </div>
                      </div>

                    </div>

                    <div class="form-group">
                      <label>Active</label>
                      <input type="checkbox" name="status" value="1" ><br>
                    </div>

                    <button type="submit" class="btn btn-primary pull-center">Submit</button>
                    <a href="<?php echo e(route('catlist')); ?>" class="btn">Close</a>
                    <div class="clearfix"></div>
                  </form>
                </div>
              </div>
            </div>
			</div>
          </div>
<?php $__env->stopSection(); ?>





<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u602795421/domains/thecodecafe.in/public_html/gogrocerlaravel/source/resources/views/admin/category/add.blade.php ENDPATH**/ ?>