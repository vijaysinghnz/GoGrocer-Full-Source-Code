<p> Hello <?php echo e($user->user_name); ?>,</p>
<p><b> We are cancelling your order (<?php echo e($cart_id); ?>) due to following reason: </b></p><br>
<p> <?php echo e($cause); ?></p><?php /**PATH /home/u602795421/domains/thecodecafe.in/public_html/gogrocer-ver2.0/source/resources/views/admin/mail/rejectmail.blade.php ENDPATH**/ ?>