
<style>
    .btn{
        height:27px !important;
    }
    .material-icons{
        margin-top:0px !important;
        margin-bottom:0px !important;
    }
</style>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    
 <div class="row">
<div class="col-lg-12">
<div class="card">    
<div class="card-header card-header-primary">
      <h4 class="card-title ">Products List</h4>
      <a href="<?php echo e(route('AddProduct')); ?>" class="btn ml-auto" style="width:10%;float:right;padding: 3px 0px 3px 0px;"><i class="material-icons">add</i> </a>

    </div>
<table class="table">
    <thead>
        <tr>
            <th class="text-center">#</th>
            <th>Product Name</th>
            <th>Category</th>
            <th>Product_image</th>
            <th class="text-right">Actions</th>
        </tr>
    </thead>
    <tbody>
           <?php if(count($product)>0): ?>
          <?php $i=1; ?>
          <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $products): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="text-center"><?php echo e($i); ?></td>
            <td><?php echo e($products->product_name); ?></td>
            <td> <?php echo e($products->title); ?></td>
            <td><img src="<?php echo e(url($products->product_image)); ?>" alt="image"  style="width:50px;height:50px; border-radius:50%"/></td>
            <td class="td-actions text-right">
                <a href="<?php echo e(route('EditProduct',$products->product_id)); ?>" rel="tooltip" class="btn btn-success">
                    <i class="material-icons">edit</i>
                </a>
                <a href="<?php echo e(route('varient',$products->product_id)); ?>" rel="tooltip" class="btn btn-primary">
                    <i class="material-icons">layers</i>
                </a>
                <a href="<?php echo e(route('DeleteProduct',$products->product_id)); ?>" rel="tooltip" class="btn btn-danger">
                    <i class="material-icons">close</i>
                </a>
            </td>
        </tr>
          <?php $i++; ?>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php else: ?>
                    <tr>
                      <td>No data found</td>
                    </tr>
                  <?php endif; ?>
    </tbody>
</table>
</div>
</div>
</div>
</div>
<div>
    </div>
    <?php $__env->stopSection(); ?>
</div>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u602795421/domains/thecodecafe.in/public_html/gogrocerlaravel/source/resources/views/admin/product/list.blade.php ENDPATH**/ ?>