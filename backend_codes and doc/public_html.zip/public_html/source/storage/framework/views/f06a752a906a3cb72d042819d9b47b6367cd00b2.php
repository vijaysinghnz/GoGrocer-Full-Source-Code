<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php echo e($logo->name); ?> store</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="icon" type="image/png" href="<?php echo e(url('assets/login/images/icons/favicon.ico')); ?>"/>
	<link rel="stylesheet" type="text/css" href="<?php echo e(url('assets/login/vendor/bootstrap/css/bootstrap.min.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(url('assets/login/fonts/font-awesome-4.7.0/css/font-awesome.min.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(url('assets/login/vendor/animate/animate.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(url('assets/login/vendor/css-hamburgers/hamburgers.min.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(url('assets/login/vendor/select2/select2.min.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(url('assets/login/css/util.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(url('assets/login/css/main.css')); ?>">
</head>
<body>
	
	<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100">
				<div class="login100-pic js-tilt" data-tilt>
					<img style="width:100px;height:auto;" src="<?php echo e(url($logo->icon)); ?>" alt="IMG">
				</div>

				<form class="login100-form validate-form" method="POST" action="<?php echo e(route('storeLoginCheck')); ?>">
					<span class="login100-form-title">
					      <?php echo e(csrf_field()); ?>

						<?php echo e($logo->name); ?> store
					</span>
                     <div class="col-lg-12">
                <?php if(session()->has('success')): ?>
               <div class="alert alert-success">
                <?php if(is_array(session()->get('success'))): ?>
                        <ul>
                            <?php $__currentLoopData = session()->get('success'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($message); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <?php else: ?>
                            <?php echo e(session()->get('success')); ?>

                        <?php endif; ?>
                    </div>
                <?php endif; ?>
                 <?php if(count($errors) > 0): ?>
                  <?php if($errors->any()): ?>
                    <div class="alert alert-danger" role="alert">
                      <?php echo e($errors->first()); ?>

                      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">×</span>
                      </button>
                    </div>
                  <?php endif; ?>
                <?php endif; ?>
                </div>
					<div class="wrap-input100 validate-input" data-validate = "Valid email is required: ex@abc.xyz">
						<input class="input100" type="text" name="email" placeholder="Email" required/>
						<span class="focus-input100"></span>
						<span class="symbol-input100">
							<i class="fa fa-envelope" aria-hidden="true"></i>
						</span>
					</div>

					<div class="wrap-input100 validate-input" data-validate = "Password is required">
						<input class="input100" type="password" name="password" placeholder="password" required/>
						 <?php echo $__env->make('admin.partials._googletagmanager', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
						<span class="focus-input100"></span>
						<span class="symbol-input100">
							<i class="fa fa-lock" aria-hidden="true"></i>
						</span>
					</div>
					
					<div class="container-login100-form-btn">
						<input class="login100-form-btn" type="submit" value="LOGIN">
						
					</div>

				</form>
			</div>
		</div>
	</div>
	
	<script src="<?php echo e(url('assets/login/vendor/jquery/jquery-3.2.1.min.js')); ?>"></script>
	<script src="<?php echo e(url('assets/login/vendor/bootstrap/js/popper.js')); ?>"></script>
	<script src="<?php echo e(url('assets/login/vendor/bootstrap/js/bootstrap.min.js')); ?>"></script>
	<script src="<?php echo e(url('assets/login/vendor/select2/select2.min.js')); ?>"></script>
	<script src="<?php echo e(url('assets/login/vendor/tilt/tilt.jquery.min.js')); ?>"></script>
	<script >
		$('.js-tilt').tilt({
			scale: 1.1
		})
	</script>
	<script src="<?php echo e(url('assets/login/js/main.js')); ?>"></script>

</body>
</html><?php /**PATH /home/u602795421/domains/thecodecafe.in/public_html/gogrocer-ver2.0/source/resources/views/store/auth/login.blade.php ENDPATH**/ ?>