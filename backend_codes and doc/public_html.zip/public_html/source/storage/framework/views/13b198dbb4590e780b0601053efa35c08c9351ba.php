<div class="sidebar" data-color="purple" data-background-color="white" data-image="../assets/img/sidebar-1.jpg">
      <div class="logo"><a href="<?php echo e(route('adminHome')); ?>" class="simple-text logo-normal">
          <?php echo e($logo->name); ?>

        </a></div>
      <div class="sidebar-wrapper">
        <ul class="nav">
     
          <li class="nav-item active  ">
            <a class="nav-link" href="<?php echo e(route('adminHome')); ?>">
              <i class="material-icons">dashboard</i>
              <p>Dashboard</p>
            </a>
          </li>
    
          <li class="nav-item">
            <a data-toggle="collapse" href="#pagesExamples" class="nav-link" aria-expanded="true">
                <i class="material-icons">settings</i>
                <p>Settings<b class="caret"></b>
                </p>
            </a>
            <div class="collapse in" id="pagesExamples" aria-expanded="true" style="">
                <ul class="nav">
                    <li style="margin-left:40px; margin-top:0px">
                        <a href="<?php echo e(route('msg91')); ?>">MSG91 API</a>
                    </li>
                    <li style="margin-left:40px; margin-top:0px">
                        <a href="<?php echo e(route('mapapi')); ?>"> Google Map API</a>
                    </li>
                    <li style="margin-left:40px; margin-top:0px">
                        <a href="<?php echo e(route('app_details')); ?>"> App Logo/Name</a>
                    </li>
                    <li style="margin-left:40px; margin-top:0px">
                        <a href="<?php echo e(route('app_details')); ?>"> Time Slot</a>
                    </li>
                    <li style="margin-left:40px; margin-top:0px">
                        <a href="<?php echo e(route('app_details')); ?>">Closing Hours</a>
                    </li>
                </ul>
            </div>
         </li>
          <li class="nav-item ">
            <a class="nav-link" href="<?php echo e(route('catlist')); ?>">
              <i class="material-icons">content_paste</i>
              <p>Category/Sub-Category</p>
            </a>
          </li>
          <li class="nav-item ">
            <a class="nav-link" href="<?php echo e(route('productlist')); ?>">
              <i class="material-icons">library_books</i>
              <p>Products</p>
            </a>
          </li>
          <li class="nav-item ">
            <a class="nav-link" href="<?php echo e(route('deallist')); ?>">
              <i class="material-icons">bubble_chart</i>
              <p>Deal Products</p>
            </a>
          </li>
          <li class="nav-item ">
            <a class="nav-link" href="#">
              <i class="material-icons">location_ons</i>
              <p>Stores</p>
            </a>
          </li>
          <li class="nav-item ">
            <a class="nav-link" href="<?php echo e(route('userlist')); ?>">
              <i class="material-icons">android</i>
              <p>App Users</p>
            </a>
          </li>
        </ul>
      </div>
    </div><?php /**PATH /home/u602795421/domains/thecodecafe.in/public_html/gogrocerlaravel/source/resources/views/admin/layout/sidebar.blade.php ENDPATH**/ ?>