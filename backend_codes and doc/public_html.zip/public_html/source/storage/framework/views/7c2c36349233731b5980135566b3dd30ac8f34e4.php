
<style>
sup {
    color:red;
    position: initial;
    font-size: 111%;
}
</style>
<?php $__env->startSection('content'); ?>
         <div class="container-fluid">
          <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title">Update Varient</h4>
                  
                     <?php if(count($errors) > 0): ?>
                      <?php if($errors->any()): ?>
                        <div class="alert alert-primary" role="alert">
                          <?php echo e($errors->first()); ?>

                          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">×</span>
                          </button>
                        </div>
                      <?php endif; ?>
                  <?php endif; ?>
                  <form class="forms-sample" action="<?php echo e(route('update-varient', $varient_id)); ?>" method="post" enctype="multipart/form-data">
                      <?php echo e(csrf_field()); ?>

                </div>
                <div class="card-body">
                     <div class="row">
                      <div class="col-md-6">
                        <div class="form-group">
                          <label for="exampleInputName1">MRP</label>
                          <input type="text" class="form-control" id="exampleInputName1" name="mrp" value="<?php echo e($product->mrp); ?>" placeholder="Enter MRP">
                        </div>
                      </div>

                    </div>
                     <div class="row">
                      <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">Quantity</label>
                          <input type="text" name="quantity" class="form-control" value="<?php echo e($product->quantity); ?>">
                        </div>
                      </div>
                    </div>
                    
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">Unit</label>
                          <input type="text" name="unit" class="form-control" value="<?php echo e($product->unit); ?>">
                        </div>
                      </div>
                    </div>
                    
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">Price</label>
                          <input type="text" name="price" class="form-control" value="<?php echo e($product->price); ?>">
                        </div>
                      </div>
                    </div>
                     <img src="<?php echo e(url($product->varient_image)); ?>" alt="image" name="old_image" style="width:100px;height:100px; border-radius:50%">
                     <div class="row">
                      <div class="col-md-6">
                        <div class="form">
                          <label class="bmd-label-floating">Varient Image</label>
                          <input type="file"name="varient_image" class="form-control">
                        </div>
                      </div>
                    </div>
                    
                     <div class="row">
                      <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">Description</label>
                          <textarea type="text" name="description" class="form-control"><?php echo e($product->description); ?></textarea>
                        </div>
                      </div>
                    </div>


                    <button type="submit" class="btn btn-primary pull-center">Submit</button>
                    <a href="<?php echo e(route('varient',$product->product_id)); ?>" class="btn">Close</a>
                    <div class="clearfix"></div>
                  </form>
                </div>
              </div>
            </div>
			</div>
          </div>       

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u602795421/domains/thecodecafe.in/public_html/gogrocerlaravel/source/resources/views/admin/product/varient/editvarient.blade.php ENDPATH**/ ?>