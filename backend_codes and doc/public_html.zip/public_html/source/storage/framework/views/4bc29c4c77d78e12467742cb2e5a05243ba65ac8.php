<html>
    <body>
        <p>Out For Delivery: Your order id #<?php echo e($cart_id); ?> contains of <?php echo e($prod_name); ?> of price rs <?php echo e($price2); ?> is Out For Delivery.Get ready.</p>
    </body>
</html><?php /**PATH /home/u602795421/domains/thecodecafe.in/public_html/gogrocer-ver2.0/source/resources/views/admin/mail/del_out.blade.php ENDPATH**/ ?>