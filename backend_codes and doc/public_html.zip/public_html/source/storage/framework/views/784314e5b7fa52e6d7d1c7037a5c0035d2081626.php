<?php $__env->startSection('content'); ?>
<div class="container-fluid">
          <div class="row">
           <div class="col-lg-12">
             <?php if(count($errors) > 0): ?>
                  <?php if($errors->any()): ?>
                    <div class="alert alert-primary" role="alert">
                      <?php echo e($errors->first()); ?>

                      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">×</span>
                      </button>
                    </div>
                  <?php endif; ?>
              <?php endif; ?>
            </div>          
             <br>
            <div class="col-md-12">
              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title">Edit Profile</h4>
                  <p class="card-category">Edit your profile</p>
                </div>
                <div class="card-body">
                  <form action="<?php echo e(route('updateprof',$admin->id)); ?>" method="post" enctype="multipart/form-data">
                      <?php echo e(csrf_field()); ?>

                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">Admin Name</label>
                          <input type="text" name="admin_name" value="<?php echo e($admin->admin_name); ?>" class="form-control">
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">Admin Email</label>
                          <input type="text" name="admin_email" value="<?php echo e($admin->admin_email); ?>" class="form-control">
                        </div>
                      </div>
                    </div>
                    <div class="row">
                     <div class="col-md-12">
                        <img src="<?php echo e(url($admin->admin_image)); ?>" style="width:100px;height:100px;border-radius:50%;" alt="admin_image" name="old_admin_image"/>
                        
                     </div>
                      <div class="col-md-12">
                        <div class="form">
                          <label class="bmd-label-floating">Admin Image</label>
                          <input type="file" name="admin_image" class="form-control">
                        </div>
                      </div>
                    </div>
                    <button type="submit" class="btn btn-primary pull-right">Update Profile</button>
                    <div class="clearfix"></div>
                  </form>
                </div>
              </div>
            </div>
			</div>
          </div>
<?php $__env->stopSection(); ?>          
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u602795421/domains/thecodecafe.in/public_html/gogrocerlaravel/source/resources/views/admin/profile/profile.blade.php ENDPATH**/ ?>