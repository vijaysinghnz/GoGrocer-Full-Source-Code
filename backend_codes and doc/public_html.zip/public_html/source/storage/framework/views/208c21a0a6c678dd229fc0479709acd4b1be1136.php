      <style type="text/css">
@media  only screen and (max-width: 768px) {

.propertyone453
{
  width: 20%;
}

.propertytwo453
{
  width: 80%;
}




}

</style>
<div class="main_three">
<div class="container-fluid">
   <div class="row">
      <div class="col-sm-4">
         <div class="row">
            <div class="col-sm-2 propertyone453">
              <img src="image/lo1.PNG" height="60" style="margin-top: 30px;">
            </div>
             <div class="col-sm-10 propertytwo453">
            <h5 class="nevwer_h5">
           Agile Delivery

        </h5>
        <p class="enter_p" style="margin-top: -5px;">
      Our proficient experts ensure quality delivery within the required timeframe.


    </p>
            </div>
         </div>
      </div>

      <div class="col-sm-4">
         <div class="row">
            <div class="col-sm-2 propertyone453">
              <img src="image/lo2.PNG" height="60" style="margin-top: 30px;">
            </div>
             <div class="col-sm-10 propertytwo453">
            <h5 class="nevwer_h5">
           Agile Delivery

        </h5>
        <p class="enter_p" style="margin-top: -5px;">
      Our proficient experts ensure quality delivery within the required timeframe.


    </p>
            </div>
         </div>
      </div>

       <div class="col-sm-4">
         <div class="row">
            <div class="col-sm-2 propertyone453">
              <img src="image/lo3.PNG" height="60" style="margin-top: 30px;">
            </div>
             <div class="col-sm-10 propertytwo453">
            <h5 class="nevwer_h5">
           Agile Delivery

        </h5>
        <p class="enter_p" style="margin-top: -5px;">
      Our proficient experts ensure quality delivery within the required timeframe.


    </p>
            </div>
         </div>
      </div>
   </div>
</div>
</div><?php /**PATH /home/u602795421/domains/thecodecafe.in/public_html/gogrocer-ver2.0/source/resources/views/web/layout/property.blade.php ENDPATH**/ ?>