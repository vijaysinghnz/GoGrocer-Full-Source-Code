<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    
          <div class="row">
              <div class="col-lg-12">
                 <?php if(count($errors) > 0): ?>
                      <?php if($errors->any()): ?>
                        <div class="alert alert-primary" role="alert">
                          <?php echo e($errors->first()); ?>

                          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">×</span>
                          </button>
                        </div>
                      <?php endif; ?>
                  <?php endif; ?>
                </div>          
             <br>
            <div class="col-md-12">
              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title">Change Password</h4>
                  <p class="card-category">change your Password</p>
                </div>
                <div class="card-body">
                  <form action="<?php echo e(route('updatepass', $admin->id)); ?>" method="post" enctype="multipart/form-data">
                      <?php echo e(csrf_field()); ?>

                    <div class="row">
                      <div class="col-md-12">
                        <div class="form-group">
                          <label class="bmd-label-floating">Current Password</label>
                          <input type="text" name="current_pass" class="form-control">
                        </div>
                      </div>
                      <div class="col-md-12">
                        <div class="form-group">
                          <label class="bmd-label-floating">New Password</label>
                          <input type="text" name="new_pass" class="form-control">
                        </div>
                      </div>
                    </div><br>
                    <button type="submit" class="btn btn-primary pull-right">Update Password</button>
                    <div class="clearfix"></div>
                  </form>
                </div>
              </div>
            </div>
			</div>
          </div>
<?php $__env->stopSection(); ?>          
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u602795421/domains/thecodecafe.in/public_html/gogrocerlaravel/source/resources/views/admin/profile/change_pass.blade.php ENDPATH**/ ?>