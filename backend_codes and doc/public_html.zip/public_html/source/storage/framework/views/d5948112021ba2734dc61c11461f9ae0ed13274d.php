<?php $__env->startSection('content'); ?>
 <div class="container-fluid">
          <div class="row">
             <div class="col-lg-12">
                <?php if(session()->has('success')): ?>
               <div class="alert alert-success">
                <?php if(is_array(session()->get('success'))): ?>
                        <ul>
                            <?php $__currentLoopData = session()->get('success'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($message); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <?php else: ?>
                            <?php echo e(session()->get('success')); ?>

                        <?php endif; ?>
                    </div>
                <?php endif; ?>
                 <?php if(count($errors) > 0): ?>
                  <?php if($errors->any()): ?>
                    <div class="alert alert-danger" role="alert">
                      <?php echo e($errors->first()); ?>

                      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">×</span>
                      </button>
                    </div>
                  <?php endif; ?>
                <?php endif; ?>
           </div> 
            <div class="col-md-12">
              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title">Edit Category</h4>
                  <form class="forms-sample" action="<?php echo e(route('UpdateCategory', $cat->cat_id)); ?>" method="post" enctype="multipart/form-data">
                      <?php echo e(csrf_field()); ?>

                </div>
                <div class="card-body">

                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">Parent Category</label>
                         <select name="parent_id" class="form-control">
                              <option value="0">No Parent</option>
                              <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorys): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        		          	<option value="<?php echo e($categorys->cat_id); ?>" <?php if( $categorys->cat_id == $cat->parent): ?> selected <?php endif; ?>><?php if($categorys->level==1): ?>-<?php endif; ?> <?php if($categorys->level==2): ?>--<?php endif; ?> <?php echo e($categorys->title); ?></option>
        		              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              
                          </select>
                        </div>
                      </div>
                        <div class="col-md-6">
                          <div class="col-md-12">
                          <p style="color:green;font-weight:bold">If you select no parent. The category you are adding it becomes main parent category.</p>
                          </div>
                      </div>
                    </div>

 
                     <div class="row">
                      <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">Category Title</label>
                          <input type="text" value="<?php echo e($cat->title); ?>" name="cat_name" class="form-control">
                        </div>
                      </div>

                    </div>
                    <img src="<?php echo e(url($cat->image)); ?>" alt="image" name="old_image" style="width:100px;height:100px; border-radius:50%">
                     <div class="row">
                      <div class="col-md-6">
                        <div class="form">
                          <label class="bmd-label-floating">Category Image</label>
                          <input type="file"name="cat_image" class="form-control">
                        </div>
                      </div>
                    </div>
                       <div class="row">
                      <div class="col-md-6">
                        <div class="form">
                          <label class="bmd-label-floating">Description</label>
                          <textarea name="desc" class="form-control"><?php echo e($cat ->description); ?></textarea>
                        </div>
                      </div>
                    </div>
                    <button type="submit" class="btn btn-primary pull-center">Submit</button>
                    <a href="<?php echo e(route('catlist')); ?>" class="btn">Close</a>
                    <div class="clearfix"></div>
                  </form>
                </div>
              </div>
            </div>
			</div>
          </div>
<?php $__env->stopSection(); ?>





<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u602795421/domains/thecodecafe.in/public_html/gogrocer-ver2.0/source/resources/views/admin/category/edit.blade.php ENDPATH**/ ?>