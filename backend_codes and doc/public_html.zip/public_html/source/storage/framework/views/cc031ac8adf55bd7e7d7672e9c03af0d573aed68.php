<div class="sidebar" data-color="purple" data-background-color="white" data-image="../assets/img/sidebar-1.jpg">
      <div class="logo"><a href="<?php echo e(route('storeHome')); ?>" class="simple-text logo-normal">
          <?php echo e($logo->name); ?> Store
        </a></div>
      <div class="sidebar-wrapper">
        <ul class="nav">
          <li class="nav-item active  ">
            <a class="nav-link" href="<?php echo e(route('storeHome')); ?>">
              <i class="material-icons">dashboard</i>
              <p>Dashboard</p>
            </a>
          </li>
          <li class="nav-item ">
            <a class="nav-link" href="<?php echo e(route('sel_product')); ?>">
              <i class="material-icons">layers</i>
              <p>Products Add</p>
            </a>
          </li>
         <!-- <li class="nav-item">-->
         <!--   <a data-toggle="collapse" href="#pagesExamples" class="nav-link" aria-expanded="true">-->
         <!--       <i class="material-icons">settings</i>-->
         <!--       <p>Settings<b class="caret"></b>-->
         <!--       </p>-->
         <!--   </a>-->
         <!--   <div class="collapse in" id="pagesExamples" aria-expanded="true" style="">-->
         <!--       <ul class="nav">-->
         <!--           <li style="margin-left:40px; margin-top:0px">-->
         <!--               <a href="#">MSG91 API</a>-->
         <!--           </li>-->
         <!--           <li style="margin-left:40px; margin-top:0px">-->
         <!--               <a href="#"> Google Map API</a>-->
         <!--           </li>-->
         <!--           <li style="margin-left:40px; margin-top:0px">-->
         <!--               <a href="#"> App Logo/Name</a>-->
         <!--           </li>-->
         <!--           <li style="margin-left:40px; margin-top:0px">-->
         <!--               <a href="#"> Time Slot</a>-->
         <!--           </li>-->
         <!--           <li style="margin-left:40px; margin-top:0px">-->
         <!--               <a href="#">Closing Hours</a>-->
         <!--           </li>-->
         <!--       </ul>-->
         <!--   </div>-->
         <!--</li>-->
         <!-- <li class="nav-item ">-->
         <!--   <a class="nav-link" href="#">-->
         <!--     <i class="material-icons">content_paste</i>-->
         <!--     <p>Category/Sub-Category</p>-->
         <!--   </a>-->
         <!-- </li>-->
         <!-- <li class="nav-item ">-->
         <!--   <a class="nav-link" href="#">-->
         <!--     <i class="material-icons">library_books</i>-->
         <!--     <p>Products</p>-->
         <!--   </a>-->
         <!-- </li>-->
         <!-- <li class="nav-item ">-->
         <!--   <a class="nav-link" href="#">-->
         <!--     <i class="material-icons">bubble_chart</i>-->
         <!--     <p>Icons</p>-->
         <!--   </a>-->
         <!-- </li>-->
         <!-- <li class="nav-item ">-->
         <!--   <a class="nav-link" href="#">-->
         <!--     <i class="material-icons">location_ons</i>-->
         <!--     <p>Stores</p>-->
         <!--   </a>-->
         <!-- </li>-->
         <!-- <li class="nav-item ">-->
         <!--   <a class="nav-link" href="#">-->
         <!--     <i class="material-icons">notifications</i>-->
         <!--     <p>Banners</p>-->
         <!--   </a>-->
         <!-- </li>-->
        </ul>
      </div>
    </div><?php /**PATH /home/u602795421/domains/thecodecafe.in/public_html/gogrocerlaravel/source/resources/views/store/layout/sidebar.blade.php ENDPATH**/ ?>