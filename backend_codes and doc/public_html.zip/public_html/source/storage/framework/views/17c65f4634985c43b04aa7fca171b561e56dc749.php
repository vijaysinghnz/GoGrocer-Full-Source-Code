<style>
.canreq_cont {
    background-color: #f6f2f2;
}
</style>
<?php $__env->startSection('content'); ?>
  <div class="container-fluid canreq_cont" align="center" style="z-index:999999 !important">
         <?= $about->description ?>
     
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u602795421/domains/thecodecafe.in/public_html/gogrocer-ver2.0/source/resources/views/web/terms.blade.php ENDPATH**/ ?>