
<style>
    .btn{
        height:27px !important;
    }
    .material-icons{
        margin-top:0px !important;
        margin-bottom:0px !important;
    }
</style>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    
 <div class="row">
<div class="col-lg-12">
<div class="card">    
<div class="card-header card-header-primary">
      <h4 class="card-title ">Deal Products</h4>
      <a href="<?php echo e(route('AddDeal')); ?>" class="btn ml-auto" style="width:10%;float:right;padding: 3px 0px 3px 0px;"><i class="material-icons">add</i> </a>
    </div>
<table class="table">
    <thead>
        <tr>
            <th class="text-center">#</th>
            <th>Product_name</th>
            <th>Deal Price</th>
            <th>Valid From</th>
            <th>Valid To</th>
            <th>Status</th>
            <th class="text-right">Actions</th>
        </tr>
    </thead>
    <tbody>
           <?php if(count($deal_p)>0): ?>
          <?php $i=1; ?>
          <?php $__currentLoopData = $deal_p; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="text-center"><?php echo e($i); ?></td>
            <td><?php echo e($deal->product_name); ?> (<?php echo e($deal->quantity); ?><?php echo e($deal->unit); ?>)</td>
            <td><?php echo e($deal->deal_price); ?></td>
            <td><?php echo e($deal->valid_from); ?></td>
            <td><?php echo e($deal->valid_to); ?></td>
            <td><?php echo e($deal->valid_to); ?></td>
            
            <td class="td-actions text-right">
                <a href="<?php echo e(route('EditDeal',$deal->deal_id)); ?>" rel="tooltip" class="btn btn-success">
                    <i class="material-icons">edit</i>
                </a>
               <a href="<?php echo e(route('DeleteDeal',$deal->deal_id)); ?>" rel="tooltip" class="btn btn-danger">
                    <i class="material-icons">close</i>
                </a>
            </td>
        </tr>
          <?php $i++; ?>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php else: ?>
                    <tr>
                      <td>No data found</td>
                    </tr>
                  <?php endif; ?>
    </tbody>
</table>
</div>
</div>
</div>
</div>
<div>
    </div>
    <?php $__env->stopSection(); ?>
</div>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u602795421/domains/thecodecafe.in/public_html/gogrocerlaravel/source/resources/views/admin/deal_product/list.blade.php ENDPATH**/ ?>