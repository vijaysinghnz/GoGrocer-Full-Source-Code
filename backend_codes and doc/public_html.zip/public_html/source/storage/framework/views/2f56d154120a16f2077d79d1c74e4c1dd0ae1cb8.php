

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
   <?php if(count($errors) > 0): ?>
                      <?php if($errors->any()): ?>
                        <div class="alert alert-primary" role="alert">
                          <?php echo e($errors->first()); ?>

                          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">×</span>
                          </button>
                        </div>
                      <?php endif; ?>
                  <?php endif; ?>  
 <div class="row">
<div class="col-lg-12">
<div class="card">    
<div class="card-header card-header-primary">
      <h4 class="card-title ">Nearby Store List</h4>
    </div>
<table class="table">
    <thead>
        <tr>
            <th class="text-center">#</th>
            <th>store_name</th>
            <th>Cart price</th>
            <th>store have</th>
            <th>Store don't have</th>
            <th class="text-right">Assign</th>
        </tr>
    </thead>
    <tbody>
           <?php if(count($nearbystores)>0): ?>
          <?php $i=1; ?>
          <?php $__currentLoopData = $nearbystores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nearbystoress): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="text-center"><?php echo e($i); ?></td>
            <td><?php echo e($nearbystoress->store_name); ?></td>
            <td><?php echo e($ord->total_price); ?></td>
              <?php if(count($storeorders)>0): ?>
           <td> <?php $__currentLoopData = $storeorders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $storeorderss): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php echo e($storeorderss->product_name); ?>,
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>
            <?php else: ?>
            <tr>
             <td>No data found</td>
            </tr>
             <?php endif; ?>
             <td></td>
            
        </tr>
          <?php $i++; ?>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php else: ?>
                    <tr>
                      <td>No data found</td>
                    </tr>
                  <?php endif; ?>
    </tbody>
</table>
</div>
</div>
</div>
</div>
<div>
</div>




    <?php $__env->stopSection(); ?>
</div>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u602795421/domains/thecodecafe.in/public_html/gogrocer-ver2.0/source/resources/views/admin/store/nearbystore.blade.php ENDPATH**/ ?>