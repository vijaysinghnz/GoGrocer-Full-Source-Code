

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
 <div class="row">
<div class="col-lg-12">
    <?php if(session()->has('success')): ?>
   <div class="alert alert-success">
    <?php if(is_array(session()->get('success'))): ?>
            <ul>
                <?php $__currentLoopData = session()->get('success'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($message); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <?php else: ?>
                <?php echo e(session()->get('success')); ?>

            <?php endif; ?>
        </div>
    <?php endif; ?>
     <?php if(count($errors) > 0): ?>
      <?php if($errors->any()): ?>
        <div class="alert alert-danger" role="alert">
          <?php echo e($errors->first()); ?>

          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
      <?php endif; ?>
    <?php endif; ?>
    </div>
<div class="col-lg-12">
<div class="card">    
<div class="card-header card-header-primary">
      <h4 class="card-title ">Store Order List</h4>
    </div>
<table class="table">
    <thead>
        <tr>
            <th class="text-center">#</th>
            <th>Cart_id</th>
            <th>Cart price</th>
            <th>User</th>
            <th>Delivery_Date</th>
            <th>Cart Products</th>
            <th class="text-right">status</th>
        </tr>
    </thead>
    <tbody>
           <?php if(count($ord)>0): ?>
          <?php $i=1; ?>
          <?php $__currentLoopData = $ord; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ords): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="text-center"><?php echo e($i); ?></td>
            <td><?php echo e($ords->cart_id); ?></td>
            <td><?php echo e($ords->total_price); ?></td>
            <td><?php echo e($ords->user_name); ?>(<?php echo e($ords->user_phone); ?>)</td>
             <td><?php echo e($ords->delivery_date); ?></td>
            <td><button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal1<?php echo e($ords->cart_id); ?>">Details</button>
            <td class="td-actions text-right">
                <?php if($ords->order_status == 'Confirmed'||$ords->order_status == 'confirmed'||$ords->order_status == 'Confirm'||$ords->order_status == 'confirm'): ?>
                <p>Confirmed</p>
                <?php endif; ?>
                <?php if($ords->order_status == 'Completed'||$ords->order_status == 'completed'||$ords->order_status == 'Completed'||$ords->order_status == 'complete'): ?>
                  <p>Completed</p>
                <?php endif; ?>
                <?php if($ords->order_status == 'PENDING'||$ords->order_status == 'pending'||$ords->order_status == 'Pending'): ?>
                  <p>Pending</p>
                <?php endif; ?>
            </td>
        </tr>
          <?php $i++; ?>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php else: ?>
                    <tr>
                      <td>No data found</td>
                    </tr>
                  <?php endif; ?>
    </tbody>
</table>
<div class="pagination justify-content-end" align="right" style="width:100%;float:right !important"><?php echo e($ord->links()); ?></div>
</div>
</div>
</div>
</div>
<div>
</div>


<!--/////////details model//////////-->
<?php $__currentLoopData = $ord; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ords): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade" id="exampleModal1<?php echo e($ords->cart_id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        	<div class="modal-dialog" role="document">
        		<div class="modal-content">
        			<div class="modal-header">
        				<h5 class="modal-title" id="exampleModalLabel">Order Details (<b><?php echo e($ords->cart_id); ?></b>)</h5>
        					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
        						<span aria-hidden="true">&times;</span>
        					</button>
        			</div>
        			<!--//form-->
        			<table class="table table-bordered" id="example2" width="100%" cellspacing="0">
                      <thead>
                        <tr>
                        <th>product details</th>
                        <th>order qty</th>
                        <th>Price</th>
                        </tr>
                      </thead>
                      
                      <tbody>
                      <?php if(count($details)>0): ?>
                                      <?php $i=1; ?>
                                      
                          <tr>             
                        <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detailss): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php if($detailss->cart_id==$ords->cart_id): ?>
                            <td><p><img style="width:25px;height:25px; border-radius:50%" src="<?php echo e(url($detailss->varient_image)); ?>" alt="$detailss->product_name">  <?php echo e($detailss->product_name); ?>(<?php echo e($detailss->quantity); ?><?php echo e($detailss->unit); ?>)</p>
                            </td>
                            <td><?php echo e($detailss->qty); ?></td>
                            <td> 
                            <p><span style="color:grey"><?php echo e($detailss->price); ?></span></p>
                           </td>
    		          	  <?php endif; ?>
                         </tr>
                            <?php $i++; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          <?php else: ?>
                            <tr>
                              <td>No data found</td>
                            </tr>
                                  <?php endif; ?>
                                   
                      </tbody>
                    </table>

        			<!--//form-->
        		</div>
        	</div>
        </div>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    <?php $__env->stopSection(); ?>
</div>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u602795421/domains/thecodecafe.in/public_html/gogrocer-ver2.0/source/resources/views/admin/store/orders.blade.php ENDPATH**/ ?>