

<?php $__env->startSection('content'); ?>
 <div class="container-fluid">
          <div class="row">
              <div class="col-lg-12">
                <?php if(session()->has('success')): ?>
               <div class="alert alert-success">
                <?php if(is_array(session()->get('success'))): ?>
                        <ul>
                            <?php $__currentLoopData = session()->get('success'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($message); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <?php else: ?>
                            <?php echo e(session()->get('success')); ?>

                        <?php endif; ?>
                    </div>
                <?php endif; ?>
                 <?php if(count($errors) > 0): ?>
                  <?php if($errors->any()): ?>
                    <div class="alert alert-danger" role="alert">
                      <?php echo e($errors->first()); ?>

                      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">×</span>
                      </button>
                    </div>
                  <?php endif; ?>
                <?php endif; ?>
                </div>
             <div class="col-md-12">
              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title">Store Products</h4>
                 </div>
                     <table class="table">
                        <thead>
                            <tr>
                                <th class="text-center">#</th>
                                <th>Product Name</th>
                                <th class="text-center">Current Stock</th>
                                <th class="text-center">Add Stock</th>
                                <th class="text-right">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                             
                              <?php if(count($selected)>0): ?>
                      <?php $i=1; ?>
                      <?php $__currentLoopData = $selected; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="text-center"><?php echo e($i); ?></td>
                        <td><p><?php echo e($sel->product_name); ?>(<?php echo e($sel->quantity); ?> <?php echo e($sel->unit); ?>)</p></td>
                        <td><?php echo e($sel->stock); ?></td>
                        <td>
                            
                         <form class="forms-sample" action="<?php echo e(route('stock_update', $sel->p_id)); ?>" method="post" enctype="multipart/form-data">
                          <?php echo e(csrf_field()); ?>

                          <div class="col-md-12">
                          <div class="col-md-8" style="float:left">
                             <div class="form-group">
                              <label class="bmd-label-floating">stock</label>
                              <input type="number" name="stock" class="form-control" value="0">
                            </div>
                          </div>
                          <div class="col-md-4" style="float:left;margin-left: -20px;">
                          <button type="submit" style="border:none;background-color:transparent;float:left;width: 40px !important;height: 40px;border-radius: 50%;"><img style="float:left;width: 40px !important;height: 40px;border-radius: 50%;" src="<?php echo e(url('images/icon/add.png')); ?>" alt="add"/></button>
                            </div>
                          </form>
                          </div>
                        </td>
                        <td class="td-actions text-right">
                           <a href="<?php echo e(route('delete_product', $sel->p_id)); ?>" rel="tooltip" class="btn btn-danger">
                                <i class="material-icons">close</i>
                            </a>
                        </td>
                    </tr>
                      <?php $i++; ?>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              <?php else: ?>
                                <tr>
                                  <td>No data found</td>
                                </tr>
                              <?php endif; ?>
                        </tbody>
                    </table>
                    <div class="pagination justify-content-end" align="right" style="width:100%;float:right !important"><?php echo e($selected->links()); ?></div>
                </div>
              </div>
            </div>
			</div>
          </div>
<?php $__env->stopSection(); ?>





<?php echo $__env->make('store.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u602795421/domains/thecodecafe.in/public_html/gogrocer-ver2.0/source/resources/views/store/products/pr.blade.php ENDPATH**/ ?>