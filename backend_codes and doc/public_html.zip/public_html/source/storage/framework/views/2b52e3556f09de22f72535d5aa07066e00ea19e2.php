<html>
    <body>
        <p> Order Successfully Placed: Your order id #<?php echo e($cart_id); ?> contains of <?php echo e($prod_name); ?> of price rs <?php echo e($price2); ?> is placed Successfully.You can expect your item(s) will be delivered on <?php echo e($delivery_date); ?> between <?php echo e($time_slot); ?>.</p>
    </body>
</html><?php /**PATH /home/u602795421/domains/thecodecafe.in/public_html/gogrocer-ver2.0/source/resources/views/admin/mail/codorderplaced.blade.php ENDPATH**/ ?>