<html>
    <body>
        <p>Amount of <?php echo e($amt); ?> marked paid successfully to <?php echo e($store_name); ?> </p>
    </body>
</html><?php /**PATH /home/u602795421/domains/thecodecafe.in/public_html/gogrocer-ver2.0/source/resources/views/admin/mail/payout.blade.php ENDPATH**/ ?>