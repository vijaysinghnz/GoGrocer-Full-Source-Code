

<?php $__env->startSection('content'); ?>
 <div class="container-fluid">
          <div class="row">
             <div class="col-lg-12">
                <?php if(session()->has('success')): ?>
               <div class="alert alert-success">
                <?php if(is_array(session()->get('success'))): ?>
                        <ul>
                            <?php $__currentLoopData = session()->get('success'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($message); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <?php else: ?>
                            <?php echo e(session()->get('success')); ?>

                        <?php endif; ?>
                    </div>
                <?php endif; ?>
                 <?php if(count($errors) > 0): ?>
                  <?php if($errors->any()): ?>
                    <div class="alert alert-danger" role="alert">
                      <?php echo e($errors->first()); ?>

                      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">×</span>
                      </button>
                    </div>
                  <?php endif; ?>
                <?php endif; ?>
                </div> 
            <div class="col-md-5">
              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title">Select Products</h4>
                  
         <form class="forms-sample" action="<?php echo e(route('added_product')); ?>" method="post" enctype="multipart/form-data">
                      <?php echo e(csrf_field()); ?>

                </div>
                <div class="card-body">

                    <div class="row">
                      <div class="col-md-12">
                        <div class="form-group">
                          <label class="bmd-label-floating">Select Products You Have</label><br>
                        <select class="mdb-select md-form form-group" name="prod[]" multiple>
                          <option value="" disabled>Choose your Product</option>
                          <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($product->varient_id); ?>"><?php echo e($product->product_name); ?>(<?php echo e($product->quantity); ?><?php echo e($product->unit); ?>)</option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>

                        </div>
                      </div>

                    </div>

                    <button type="submit" class="btn btn-primary pull-center">Submit</button>
                    <div class="clearfix"></div>
                  </form>
                </div>
              </div>
            </div>
             <div class="col-md-7">
              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title">Selected Products</h4>
                 </div>
                     <table class="table">
                        <thead>
                            <tr>
                                <th class="text-center">#</th>
                                <th style="width:33.33%">Product Name</th>
                                <th class="text-center" style="width:33.33%">Current Stock</th>
                                <th class="text-right" style="width:33.33%">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                             
                              <?php if(count($selected)>0): ?>
                      <?php $i=1; ?>
                      <?php $__currentLoopData = $selected; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="text-center"><?php echo e($i); ?></td>
                        <td><p><?php echo e($sel->product_name); ?>(<?php echo e($sel->quantity); ?> <?php echo e($sel->unit); ?>)</p></td>
                        <td align="center"><?php echo e($sel->stock); ?></td>
                        <td class="td-actions text-right">
                           <a href="<?php echo e(route('delete_product', $sel->p_id)); ?>" rel="tooltip" class="btn btn-danger">
                                <i class="material-icons">close</i>
                            </a>
                        </td>
                    </tr>
                      <?php $i++; ?>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              <?php else: ?>
                                <tr>
                                  <td>No data found</td>
                                </tr>
                              <?php endif; ?>
                        </tbody>
                    </table>
                    <div class="pagination justify-content-end" align="right" style="width:100%;float:right !important"><?php echo e($selected->links()); ?></div>
                </div>
              </div>
            </div>
			</div>
          </div>
<?php $__env->stopSection(); ?>





<?php echo $__env->make('store.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u602795421/domains/thecodecafe.in/public_html/gogrocer-ver2.0/source/resources/views/store/products/select.blade.php ENDPATH**/ ?>