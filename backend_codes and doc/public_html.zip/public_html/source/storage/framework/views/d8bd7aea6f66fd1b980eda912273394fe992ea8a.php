<div class="sidebar" data-color="purple" data-background-color="white" data-image="../assets/img/sidebar-1.jpg">
      <div class="logo"><a href="<?php echo e(route('storeHome')); ?>" class="simple-text logo-normal">
          <?php echo e($logo->name); ?> Store
        </a></div>
      <div class="sidebar-wrapper">
        <ul class="nav">
          <li class="nav-item active  ">
            <a class="nav-link" href="<?php echo e(route('storeHome')); ?>">
              <i class="material-icons">dashboard</i>
              <p>Dashboard</p>
            </a>
          </li>
           <li class="nav-item ">
            <a class="nav-link" href="<?php echo e(route('payout_req')); ?>">
              <i class="material-icons">layers</i>
              <p>Send Payout Request</p>
            </a>
          </li>
           <li class="nav-item ">
            <a class="nav-link" href="<?php echo e(route('st_product')); ?>">
              <i class="material-icons">layers</i>
              <p>Update Stock</p>
            </a>
          </li>
          <li class="nav-item ">
            <a class="nav-link" href="<?php echo e(route('sel_product')); ?>">
              <i class="material-icons">layers</i>
              <p>Products Add</p>
            </a>
          </li>
            <li class="nav-item">
            <a class="nav-link" data-toggle="collapse" href="#setting-dropdown2" aria-expanded="false" aria-controls="setting-dropdown">
              <i class="menu-icon fa fa-calendar"></i>
              <span class="menu-title">Orders<b class="caret"></b></span>
            </a>
            <div class="collapse" id="setting-dropdown2">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item">
                  <a class="nav-link" href="<?php echo e(route('storeOrders')); ?>">Unassigned Orders</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="<?php echo e(route('storeassignedorders')); ?>">Assigned Orders</a>
                </li>

                </ul>
                </div>
          </li>
         
        </ul>
      </div>
    </div><?php /**PATH /home/u602795421/domains/thecodecafe.in/public_html/gogrocer-ver2.0/source/resources/views/store/layout/sidebar.blade.php ENDPATH**/ ?>