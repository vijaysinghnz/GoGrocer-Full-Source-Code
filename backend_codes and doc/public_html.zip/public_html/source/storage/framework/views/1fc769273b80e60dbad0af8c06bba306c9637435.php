

<?php $__env->startSection('content'); ?>
 <div class="container-fluid">
          <div class="row">
             <div class="col-lg-12">
                <?php if(session()->has('success')): ?>
               <div class="alert alert-success">
                <?php if(is_array(session()->get('success'))): ?>
                        <ul>
                            <?php $__currentLoopData = session()->get('success'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($message); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <?php else: ?>
                            <?php echo e(session()->get('success')); ?>

                        <?php endif; ?>
                    </div>
                <?php endif; ?>
                 <?php if(count($errors) > 0): ?>
                  <?php if($errors->any()): ?>
                    <div class="alert alert-danger" role="alert">
                      <?php echo e($errors->first()); ?>

                      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">×</span>
                      </button>
                    </div>
                  <?php endif; ?>
                <?php endif; ?>
                </div> 
            <div class="col-md-12">
              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title">Payment Method Setting</h4>
                  <b><?php if($pymnt->razorpay == 1 && $pymnt->paypal == 0): ?> Razorpay is ON &nbsp;<span style="height: 12px;width: 12px;background-color: green;border-radius: 50%;display: inline-block;" class="dot"></span> <?php endif; ?>
                  <?php if($pymnt->razorpay == 0 && $pymnt->paypal == 1): ?> Paypal is ON &nbsp;<span style="height: 12px;width: 12px;background-color: green;border-radius: 50%;display: inline-block;" class="dot"></span> <?php endif; ?> 
                  <?php if($pymnt->razorpay == 1 && $pymnt->paypal == 1): ?> Razorpay and Paypal both are ON &nbsp;<span style="height: 12px;width: 12px;background-color: green;border-radius: 50%;display: inline-block;" class="dot"></span> <?php endif; ?></b>
                  
                 </div> 
                <div class="container">
            <form action="<?php echo e(route('updategateway')); ?>" method="POST">     
            <?php echo e(csrf_field()); ?>

                 <div class="form-group">    
                <span>Select Your Payment Method</span>
                <select id="ddlPassport" class="form-control" name="pymnt_via">
                    <option disabled selected>Select Your Payment Method <i class="material_icons">setting</i></option>
                    <option value="razor" <?php if($pymnt->razorpay == 1 && $pymnt->paypal == 0): ?>selected <?php endif; ?>>Razorpay</option>
                    <option value="paypal" <?php if($pymnt->razorpay == 0 && $pymnt->paypal == 1): ?>selected <?php endif; ?>>Paypal</option>
                    <option value="both" <?php if($pymnt->razorpay == 1 && $pymnt->paypal == 1): ?> selected <?php endif; ?>>Both</option>
                </select>
                </div>
                <input type="submit" class="btn btn-primary" value="SUBMIT"><br><br>
            </form> 
              </div>
            </div>
			</div>
          </div>
          </div>
<?php $__env->stopSection(); ?>





<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u602795421/domains/thecodecafe.in/public_html/newgrocer/source/resources/views/admin/settings/pymnt.blade.php ENDPATH**/ ?>