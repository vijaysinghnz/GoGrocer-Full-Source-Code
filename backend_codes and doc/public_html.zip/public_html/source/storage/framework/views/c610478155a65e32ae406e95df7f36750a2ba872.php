<?php $__env->startSection('content'); ?>
 <div class="container-fluid">
          <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title">App Setting</h4>
                  
                     <?php if(count($errors) > 0): ?>
                      <?php if($errors->any()): ?>
                        <div class="alert alert-primary" role="alert">
                          <?php echo e($errors->first()); ?>

                          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">×</span>
                          </button>
                        </div>
                      <?php endif; ?>
                  <?php endif; ?>
                  <form class="forms-sample" action="<?php echo e(route('updateappdetails')); ?>" method="post" enctype="multipart/form-data">
                      <?php echo e(csrf_field()); ?>

                </div>
                <div class="card-body">
 
                     <div class="row">
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">App Name</label>
                          <input type="text"name="app_name" value="<?php echo e(($logo->name)); ?>" class="form-control">
                        </div>
                      </div>

                    </div>
                    
                     <img src="<?php echo e(url($logo->icon)); ?>" alt="app logo" class="rounded-circle" style="width:100px; height:100px;">
                     
                     <div class="row">
                      <div class="col-md-4">
                        <div class="form">
                          <label class="bmd-label-floating">App Icon</label>
                          <input type="file"name="app_icon" class="form-control">
                        </div>
                      </div>

                    </div>
                    
                    <button type="submit" class="btn btn-primary pull-center">Submit</button>
                    <div class="clearfix"></div>
                  </form>
                </div>
              </div>
            </div>
			</div>
          </div>
<?php $__env->stopSection(); ?>





<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u602795421/domains/thecodecafe.in/public_html/gogrocerlaravel/source/resources/views/admin/settings/app_details.blade.php ENDPATH**/ ?>