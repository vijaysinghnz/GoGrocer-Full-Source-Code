
<style>
    .btn{
        height:27px !important;
    }
    .material-icons{
        margin-top:0px !important;
        margin-bottom:0px !important;
    }
</style>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    
 <div class="row">
<div class="col-lg-12">
<div class="card">    
<div class="card-header card-header-primary">
      <h4 class="card-title ">App Users</h4>
    </div>
<table class="table">
    <thead>
        <tr>
            <th class="text-center">#</th>
            <th>User_name</th>
            <th>User Phone</th>
            <th>User Email</th>
            <th>Is Verified</th>
            <th class="text-right">Active/Block</th>
        </tr>
    </thead>
    <tbody>
           <?php if(count($users)>0): ?>
          <?php $i=1; ?>
          <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="text-center"><?php echo e($i); ?></td>
            <td><?php echo e($user->user_name); ?></td>
            <td><?php echo e($user->user_phone); ?></td>
            <td><?php echo e($user->user_email); ?></td>
            <?php if($user->is_verified==0): ?>
            <td style="color:red">Not Verified</td>
            <?php else: ?>
            <td style="color:green">Verified</td>
            <?php endif; ?>
            
               
            <td class="td-actions text-right">
                 <?php if($user->block==1): ?>
               <a href="<?php echo e(route('userunblock',$user->user_id)); ?>" rel="tooltip" class="btn btn-danger">
                    <i class="material-icons">block</i>Blocked
                </a>
                <?php else: ?>
                <a href="<?php echo e(route('userblock',$user->user_id)); ?>" rel="tooltip" class="btn btn-primary">
                    <i class="material-icons">check</i>Active
                </a>
                <?php endif; ?>
            </td>
        </tr>
          <?php $i++; ?>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php else: ?>
                    <tr>
                      <td>No data found</td>
                    </tr>
                  <?php endif; ?>
    </tbody>
</table>
</div>
</div>
</div>
</div>
<div>
    </div>
    <?php $__env->stopSection(); ?>
</div>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u602795421/domains/thecodecafe.in/public_html/gogrocerlaravel/source/resources/views/admin/user/list.blade.php ENDPATH**/ ?>