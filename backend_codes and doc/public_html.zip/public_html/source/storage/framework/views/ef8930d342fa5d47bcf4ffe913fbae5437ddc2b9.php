
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Invoice</title>
        <style>
 html {
    width: 180px;
}
  * {
    font-size: 12px;
    font-family: 'Times New Roman';
}

td,
th,
tr,
table {
    border-top: 1px solid black;
    border-collapse: collapse;
}

td.description,
th.description {
    width: 65px;
    max-width: 65px;
}

td.quantity,
th.quantity {
    width: 30px;
    max-width: 30px;
    word-break: break-all;
}

td.price,
th.price {
    width: 40px;
    max-width: 40px;
    word-break: break-all;
}

.centered {
    text-align: center;
    align-content: center;
}

.ticket {
    width: 155px;
    max-width: 155px;
}

img {
    max-width: inherit;
    width: inherit;
}

@media  print {
    .hidden-print,
    .hidden-print * {
        display: none !important;
    }
}  </style>
    </head>
    <body>
        <div class="ticket" align="center">
            <img src="<?php echo e(url($logo->icon)); ?>" alt="app-logo" style="width:40px"/>
            <p class="centered">ADDRESS-
            <p> <b>Name</b> : <?php echo e($order->user_name); ?><br>
            <b>Address</b> : <?php echo e($order->house_no); ?>,<?php echo e($order->society); ?>,<?php echo e($order->landmark); ?>,<?php echo e($order->city); ?>,<?php echo e($order->state); ?>,<?php echo e($order->pincode); ?></br>
            <b>Email</b> : <?php echo e($order->user_email); ?></br>
            <b>Phone</b> : <?php echo e($order->user_phone); ?></br>
        </p></p>
            <table>
                <thead>
                    <tr>
                        <th class="quantity" align="left">#</th>
                        <th class="description" align="left">Item</th>
                        <th class="price" align="left">Qty</th>
                        <th class="price" align="left">Price</th>
                    </tr>
                </thead>
                <tbody>
                     <?php if(count($details)>0): ?>
                          <?php $i=1; ?>
                          <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          
							<tr class="service">
							     <td class="quantity" align="left"><?php echo e($i); ?></td>
								<td class="description" align="left"><?php echo e($detail->product_name); ?></td>
								<td class="price" align="left"><?php echo e($detail->qty); ?></td>
								<td class="price" align="left"><?php echo e($detail->price); ?></td>
							</tr>
							   <?php $i++; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <?php else: ?>
                        <tr>
                          <td>No data found</td>
                        </tr>
                      <?php endif; ?>  
                      <tr class="service">
							     <td class="quantity"></td>
								<td class="description"><b>PRICE</b></td>
								<td class="price"></td>
								<td class="price"><?php echo e($order->total_price); ?></td>
							</tr>
                      
                </tbody>
            </table>
            <p class="centered">Thanks for your purchase!
        </div>
        <button id="btnPrint" class="hidden-print">Print</button>
        <script>const $btnPrint = document.querySelector("#btnPrint");
$btnPrint.addEventListener("click", () => {
    window.print();
});</script>
    </body>
</html><?php /**PATH /home/u602795421/domains/thecodecafe.in/public_html/newgrocer/source/resources/views/admin/invoice/invoice.blade.php ENDPATH**/ ?>