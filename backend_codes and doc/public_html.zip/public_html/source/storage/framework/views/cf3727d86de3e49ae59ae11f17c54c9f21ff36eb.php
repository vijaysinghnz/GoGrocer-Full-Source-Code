
<style>
    div#headingone12 {
    margin-top: 4px !important;
}
</style>
<?php $__env->startSection('content'); ?>

<script>
$(document).ready(function(){
  $("#bu1234").click(function(){
    $("#bod1234").show(500);
     $("#dus1234").show();
      $("#bu1234").hide();

  });

   $("#dus1234").click(function(){
    $("#bod1234").hide(500);
     $("#dus1234").hide();
      $("#bu1234").show();

  });
 
});
</script>

<div class="container-fluid canreq_cont">
  <div class="row">
  <div class="col-sm-3">
    <div class="bs-example card filter_pro_duct12">

<h5 class="side_filter">Categories</h5>


<span style="float: right;display: none;padding-right: 22px;" id="dus1234"><i class="fas fa-angle-up"></i></span></h5>

 <div class="accordion" id="bod1234" style="display: none;">
     
      <?php if(count($category)>0): ?>
        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <div>
            <?php if($cat->parent == 0): ?>
         <div class="scard-header" id="headingOne" style="margin-bottom: -7px;margin-top: 14px;">
           
            <a data-toggle="collapse" class="collapsed main_side_head"  href="#collapse<?php echo e($cat->cat_id); ?>" style="text-decoration: none;color: black;font-weight: 500"><?php echo e($cat->title); ?>(P)
             
            <span style="float: right;margin-right:13px;">
                <i class="fa fa-plus" ></i></span>
               
               
         </a>
         </div>
          <?php $__currentLoopData = $category_sub; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat_sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($cat_sub->parent==$cat->cat_id): ?>
            <div id="collapse<?php echo e($cat_sub->parent); ?>" style="margin-top: 3px;" class="collapse sec_para_side show" aria-labelledby="headingOne">
                <div class="card-body" style="margin-bottom: -35px;">
                     <div class="" style="min-width: 235px !important;margin-left: -27px;padding-bottom: 20px;margin-top: -22px;">
                          <div>
                              
                              
                               <div class="scard-header" id="headingone12" style="margin-bottom: -7px;margin-top: 14px;">
                                   <a href="" data-toggle="collapse" class="collapsed main_side_head"></a>
                                   <a   style="text-decoration: none;color:#ea4444;font-size:13px !important" href="<?php echo e(route('catee', [$cat_sub->cat_id])); ?>" ><?php echo e($cat_sub->title); ?>

                                 
                              <span style="float: right;margin-right:13px;">
                                  <i class="fa fa-plus" ></i></span>
                                
                                  </a> 
                               </div>
                                <?php if(count($category_child)>0): ?>
                                 <?php $__currentLoopData = $category_child; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat_child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               <?php if($cat_sub->cat_id==$cat_child->parent): ?> 
                              <div id="collapseone<?php echo e($cat_child->parent); ?>" style="margin-top: 3px;" class="collapse sec_para_side" aria-labelledby="headingone12" >
                                <div class="card-body"  style="margin-bottom: -35px;">
                                    <p class="main_side_para"><?php echo e($cat_child->title); ?>(child-cat)</p>
                                   
                    
                                </div>
                            </div>
                                <?php endif; ?>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              <?php endif; ?>
                          </div>
                     </div>
                </div>
            
            </div>
            
              <?php endif; ?>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             <?php endif; ?>
       </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <?php endif; ?>
        
    
 </div>
    <br>
</div>

<div class="card filter_pro_duct1212">
  <h5 class="side_filter" style="background-color: white;z-index: 999">Price (&#8377;) </h5>

      <div class="card-body side_price_scroll">
       <form>
  <input type="checkbox" id="fruit1" name="fruit-1" value="Apple">
  <label for="fruit1">0 &#8377; - 500 &#8377;</label>
  
  

    <input type="checkbox" id="fruit2" name="fruit-2" value="afef">
  <label for="fruit2">500 &#8377; - 1000 &#8377;</label>
  
  <input type="checkbox" id="fruit3" name="fruit-3" value="dfwefw">
  <label for="fruit3">1000 &#8377; - 2000 &#8377;</label>

  <input type="checkbox" id="fruit4" name="fruit-4" value="sdfsd">
  <label for="fruit4">2000 &#8377; - 5000 &#8377;</label>

   <input type="checkbox" id="fruit5" name="fruit-5" value="sdfsd">
  <label for="fruit5">5000 &#8377; - 10000 &#8377;</label>

  <input type="checkbox" id="fruit3" name="fruit-3" value="dfwefw">
  <label for="fruit3">Strawberry</label>

  <input type="checkbox" id="fruit4" name="fruit-4" value="sdfsd">
  <label for="fruit4">Strawberry</label>

   <input type="checkbox" id="fruit5" name="fruit-5" value="sdfsd">
  <label for="fruit5">Dabur</label>


</form>
      </div>
    </div>

<div class="card filter_pro_duct1212">
  <h5 class="side_filter" style="background-color: white;z-index: 999">Brands </h5>

      <div class="card-body side_price_scroll">
       <form>
  <input type="checkbox" id="fruit1" name="fruit-1" value="Apple">
  <label for="fruit1">Apple</label>
  
  

    <input type="checkbox" id="fruit2" name="fruit-2" value="afef">
  <label for="fruit2">Apple</label>
  
  <input type="checkbox" id="fruit3" name="fruit-3" value="dfwefw">
  <label for="fruit3">Strawberry</label>

  <input type="checkbox" id="fruit4" name="fruit-4" value="sdfsd">
  <label for="fruit4">Strawberry</label>

   <input type="checkbox" id="fruit5" name="fruit-5" value="sdfsd">
  <label for="fruit5">Dabur</label>

  <input type="checkbox" id="fruit3" name="fruit-3" value="dfwefw">
  <label for="fruit3">Strawberry</label>

  <input type="checkbox" id="fruit4" name="fruit-4" value="sdfsd">
  <label for="fruit4">Strawberry</label>

   <input type="checkbox" id="fruit5" name="fruit-5" value="sdfsd">
  <label for="fruit5">Dabur</label>


</form>
      </div>
    </div>

  </div>



    <div class="col-sm-9" style="margin-left: -45px;">

      <div class="card shadow-sm top_price_menu">
  <div class="card-body">
   <button class="sort_by_but">Sort By Popularity</button>

     <button class="sort_by_but2">Price (Low To High)</button>

     <button class="sort_by_but2">Price (High To Low)</button>
    
  </div>
</div>

<div class="card shadow-sm main_card12_width">
  <div class="card-body">
  <?php if(count($products)>0): ?>
   <?php $i=1; ?>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         
<!--<a href="product_preview.php" style="color: black;">-->
  <div class="product_div">
     
       <?php 
       $prev_url= url('/');
       
       $base_url= str_replace('-web','', url('/'));
       
       $url= str_replace('gogrocer-ver2.0','gogrocer-ver2.0/', $base_url);
       ?>
  <center>
    <img src="<?=$url?><?php echo e($product->product_image); ?>" class="product_image">
  </center>
<div style="height: 85px;">
  <p class="product_name"><img src="<?=$prev_url?>/webstyle/image/green.PNG" style="margin-right: 5px;"><?php echo e($product->product_name); ?></p>

  <p class="product_brand">Exotic Fruits</p>
 <?php $__currentLoopData = $prod_variant; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if($variant->product_id==$product->product_id[$i]): ?>
<p class="product_prize">$5.00<?php echo e($variant->price); ?></p>
<?php endif; ?>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<select class="form-control product_select">
    <?php $__currentLoopData = $prod_variant; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if($variant->product_id==$product->product_id): ?>
  <option><?php echo e($variant->quantity); ?><?php echo e($variant->unit); ?>-Rs<span><?php echo e($variant->mrp); ?> </span></option>
     <?php endif; ?>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>

<div class="btn-group btn-group-sm but_div" role="group" aria-label="...">
  <button class="but_minus"><i class="fas fa-minus"></i></button>
  <button class="but_one">1</button>
  <button class="but_plus"><i class="fas fa-plus"></i></button>
  <button class="add_once">Add <span id="once_but12">Once</span></button>
</div>

<button class="but_subcribe"><i class="fas fa-bell"></i> &nbsp;Subcribe</button>

</div>
<!--</a>-->
      <?php $i++; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <?php endif; ?>
  </div>
</div>

    </div>

  </div>
</div>


<br>

 <?php $__env->stopSection(); ?> 
<script>
    $(document).ready(function(){
        // Add minus icon for collapse element which is open by default
        $(".collapse.show").each(function(){
          $(this).prev(".scard-header").find(".fa").addClass("fa-minus").removeClass("fa-plus");
        });
        
        // Toggle plus minus icon on show hide of collapse element
        $(".collapse").on('show.bs.collapse', function(){
          $(this).prev(".scard-header").find(".fa").removeClass("fa-plus").addClass("fa-minus");
        }).on('hide.bs.collapse', function(){
          $(this).prev(".scard-header").find(".fa").removeClass("fa-minus").addClass("fa-plus");
        });
    });
</script>
	<script>
		    function getData(){
		        url = "https://thecodecafe.in/gogrocer-ver2.0/api/banner";
		        fetch(url).then((response)=>{
		            console.log("inside first then")
		            return response.json();
		        }).then((data)=>{
		            console.log("inside second then")
		            console.log(data);
		        })
		    }
		    
		    getData()
		</script>
<?php echo $__env->make('web.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u602795421/domains/thecodecafe.in/public_html/gogrocer-ver2.0/source/resources/views/web/product/cat_product.blade.php ENDPATH**/ ?>