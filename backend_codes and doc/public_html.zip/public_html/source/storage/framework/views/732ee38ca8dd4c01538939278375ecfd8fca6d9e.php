      <footer class="footer">
        <div class="container-fluid">
          <div class="copyright float-right">
            &copy;
            <script>
              document.write(new Date().getFullYear())
            </script>, made with <i class="material-icons">favorite</i> by
            <a href="" target="_blank"><?php echo e($logo->name); ?></a> 
          </div>
        </div>
      </footer><?php /**PATH /home/u602795421/domains/thecodecafe.in/public_html/gogrocerlaravel/source/resources/views/store/layout/footer.blade.php ENDPATH**/ ?>