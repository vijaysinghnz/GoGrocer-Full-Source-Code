<html>
    <body>
        <p>Recharge Successful: Your recharge of <?php echo e($currency->currency_sign); ?> <?php echo e($add_to_wallet); ?> is successful.</p>
    </body>
</html><?php /**PATH /home/u602795421/domains/thecodecafe.in/public_html/gogrocer-ver2.0/source/resources/views/admin/mail/recharge.blade.php ENDPATH**/ ?>