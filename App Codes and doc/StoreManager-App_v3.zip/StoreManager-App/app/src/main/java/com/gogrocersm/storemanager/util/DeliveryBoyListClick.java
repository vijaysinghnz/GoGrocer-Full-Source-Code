package com.gogrocersm.storemanager.util;

public interface DeliveryBoyListClick {

    void onClick(int position);
}
