package com.gogrocersm.storemanager.util;

public interface StockUpdaterInterface {
    void onStockUpdate(int position);
}
