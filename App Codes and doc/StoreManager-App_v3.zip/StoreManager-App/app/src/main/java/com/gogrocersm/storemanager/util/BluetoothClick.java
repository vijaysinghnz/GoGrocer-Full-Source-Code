package com.gogrocersm.storemanager.util;

public interface BluetoothClick {
    void onClick(int position);
}
