package com.gogrocersm.storemanager.util;

public interface AllProductClickListner {
    void onClick(int position);
}
