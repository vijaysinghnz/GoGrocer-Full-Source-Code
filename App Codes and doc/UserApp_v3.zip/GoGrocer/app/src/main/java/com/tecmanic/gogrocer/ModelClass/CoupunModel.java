package com.tecmanic.gogrocer.ModelClass;

public class CoupunModel {


    private String coupon_id;
    private String coupon_name;
    private String coupon_code;
    private String coupon_description;
    private String start_date;
    private String end_date;
    private String cart_value;
    private String amount;
    private String type;
    private String uses_restriction;

    public String getCoupon_id() {
        return coupon_id;
    }

    public void setCoupon_id(String coupon_id) {
        this.coupon_id = coupon_id;
    }

    public String getCoupon_name() {
        return coupon_name;
    }

    public void setCoupon_name(String coupon_name) {
        this.coupon_name = coupon_name;
    }

    public String getCoupon_code() {
        return coupon_code;
    }

    public void setCoupon_code(String coupon_code) {
        this.coupon_code = coupon_code;
    }

    public String getCoupon_description() {
        return coupon_description;
    }

    public void setCoupon_description(String coupon_description) {
        this.coupon_description = coupon_description;
    }

    public String getStart_date() {
        return start_date;
    }

    public void setStart_date(String start_date) {
        this.start_date = start_date;
    }

    public String getEnd_date() {
        return end_date;
    }

    public void setEnd_date(String end_date) {
        this.end_date = end_date;
    }

    public String getCart_value() {
        return cart_value;
    }

    public void setCart_value(String cart_value) {
        this.cart_value = cart_value;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getUses_restriction() {
        return uses_restriction;
    }

    public void setUses_restriction(String uses_restriction) {
        this.uses_restriction = uses_restriction;
    }

    //    String coupon_id, coupon_name, coupon_code, coupon_description, valid_to, valid_from, cart_value, amount, type;
//
//
//    public String getCoupon_id() {
//        return coupon_id;
//    }
//
//    public void setCoupon_id(String coupon_id) {
//        this.coupon_id = coupon_id;
//    }
//
//    public String getCoupon_name() {
//        return coupon_name;
//    }
//
//    public void setCoupon_name(String coupon_name) {
//        this.coupon_name = coupon_name;
//    }
//
//    public String getCoupon_code() {
//        return coupon_code;
//    }
//
//    public void setCoupon_code(String coupon_code) {
//        this.coupon_code = coupon_code;
//    }
//
//    public String getCoupon_description() {
//        return coupon_description;
//    }
//
//    public void setCoupon_description(String coupon_description) {
//        this.coupon_description = coupon_description;
//    }
//
//    public String getValid_to() {
//        return valid_to;
//    }
//
//    public void setValid_to(String valid_to) {
//        this.valid_to = valid_to;
//    }
//
//    public String getValid_from() {
//        return valid_from;
//    }
//
//    public void setValid_from(String valid_from) {
//        this.valid_from = valid_from;
//    }
//
//    public String getCart_value() {
//        return cart_value;
//    }
//
//    public void setCart_value(String cart_value) {
//        this.cart_value = cart_value;
//    }
//
//    public String getAmount() {
//        return amount;
//    }
//
//    public void setAmount(String amount) {
//        this.amount = amount;
//    }
//
//    public String getType() {
//        return type;
//    }
//
//    public void setType(String type) {
//        this.type = type;
//    }
}
