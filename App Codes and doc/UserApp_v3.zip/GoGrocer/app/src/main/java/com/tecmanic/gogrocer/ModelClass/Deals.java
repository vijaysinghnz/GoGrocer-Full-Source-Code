package com.tecmanic.gogrocer.ModelClass;

public class Deals {
}
