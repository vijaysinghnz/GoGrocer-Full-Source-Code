package com.tecmanic.gogrocer.util;

public interface ViewNotifier {
    void onViewNotify();
}
