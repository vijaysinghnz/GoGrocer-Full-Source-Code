package com.tecmanic.gogrocer.Activity;

public class PayPalConfig {
    public static final String PAYPAL_CLIENT_ID = "AbqP_5GMFtyumprpmDkeme0mqsI5_UlqrPxVqaadygVCLnF09rZ_YPBisP2a3Ji0G-nQhz8pOpMO4Nkq";
}


