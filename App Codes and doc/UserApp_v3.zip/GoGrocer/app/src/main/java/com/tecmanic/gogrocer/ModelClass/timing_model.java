package com.tecmanic.gogrocer.ModelClass;

public class timing_model {
    String timing;

    public String getTiming() {
        return timing;
    }

    public void setTiming(String timing) {
        this.timing = timing;
    }
}
