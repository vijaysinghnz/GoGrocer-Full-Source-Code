package com.tecmanic.gogrocer.util;

public interface CoupounClickListner {

    void onClickApply(String couponCode);
}
