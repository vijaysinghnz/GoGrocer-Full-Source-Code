package com.tecmanic.gogrocer.Activity;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.tecmanic.gogrocer.R;

public class MainActivityAgain extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_again);
    }
}
